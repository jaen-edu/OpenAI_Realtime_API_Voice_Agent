from sales_agent.adapters.csv_repository import CsvSalesRepository


# 모든 테스트 CSV가 공유하는 헤더 줄(컬럼 이름). 끝의 \n은 줄바꿈.
HEADER = "date,product,region,quantity,unit_price\n"


def test_loads_valid_rows(csv_file):
    """정상 행은 SalesRecord로 적재된다."""
    # csv_file(...)에 '헤더 + 정상 데이터 1행' 문자열을 넘겨 임시 CSV를 만든다.
    path = csv_file(HEADER + "2024-01-05,노트북,서울,3,1200000\n")
    repo = CsvSalesRepository(str(path))  # 어댑터에 파일 경로를 주입

    records = repo.load()  # 실제 적재 수행

    assert len(records) == 1               # 정상 행 1건이 적재됨
    assert records[0].product == "노트북"   # 값이 올바르게 매핑됐는가
    assert records[0].revenue == 3_600_000  # 3 × 1,200,000 (도메인 계산이 동작)


def test_skips_invalid_quantity_with_reason(csv_file):
    """수량이 0 이하인 행은 제외되고, 그 사유가 기록된다."""
    path = csv_file(
        HEADER
        + "2024-01-05,노트북,서울,3,1200000\n"   # 정상 행
        + "2024-01-06,마우스,부산,0,25000\n"      # 수량 0 → 제외 대상
    )
    repo = CsvSalesRepository(str(path))

    records = repo.load()

    assert len(records) == 1                 # 정상 행만 남는다(잘못된 행 제외)
    assert len(repo.skipped) == 1            # 제외 보고가 정확히 1건
    assert "quantity" in repo.skipped[0].reason  # 사유에 원인('quantity')이 담겨 있다


def test_skips_bad_date(csv_file):
    """날짜 형식이 잘못된 행은 제외된다."""
    # 2024/13/40 은 존재할 수 없는 날짜(13월 40일) → 변환 실패 → 제외
    path = csv_file(HEADER + "2024/13/40,노트북,서울,3,1200000\n")
    repo = CsvSalesRepository(str(path))

    records = repo.load()

    assert records == []          # 적재된 정상 행이 없다
    assert len(repo.skipped) == 1  # 그 행은 사유와 함께 제외 보고됨


def test_missing_required_column_raises(csv_file):
    """필수 컬럼이 통째로 없으면(데이터 구조 자체가 잘못) 오류를 던진다."""
    import pytest

    # unit_price 컬럼이 아예 없는 CSV → 행 단위 문제가 아니라 '파일 구조' 문제
    path = csv_file("date,product,region,quantity\n2024-01-05,노트북,서울,3\n")
    repo = CsvSalesRepository(str(path))

    with pytest.raises(ValueError):  # 건너뛰지 않고 전체를 중단(예외)해야 정상
        repo.load()