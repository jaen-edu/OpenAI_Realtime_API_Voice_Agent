from datetime import date

import pytest  # 테스트 프레임워크. raises 등 검증 도구를 제공한다.

from sales_agent.domain.errors import InvalidSalesRecordError
from sales_agent.domain.models import SalesRecord


def make(**overrides) -> SalesRecord:
    """기본값으로 SalesRecord를 만들고, 인자로 넘긴 필드만 덮어쓰는 테스트 헬퍼.

    **overrides: 호출 시 키워드 인자로 넘긴 값들이 dict로 모인다.
                 예) make(quantity=0) → overrides == {"quantity": 0}

    이 헬퍼가 있으면 각 테스트는 '바꾸고 싶은 값 하나'만 적으면 되어,
    "이 테스트가 무엇을 검증하는지"가 한눈에 드러난다.
    """
    # 모든 필드가 유효한 '정상 레코드'를 기본값으로 준비한다.
    base = dict(
        date=date(2024, 1, 5),
        product="노트북",
        region="서울",
        quantity=3,
        unit_price=1_200_000.0,
    )
    base.update(overrides)        # 넘어온 값만 기본값 위에 덮어쓴다
    return SalesRecord(**base)    # dict를 키워드 인자로 풀어 생성(**) → SalesRecord(date=..., ...)


def test_revenue_is_quantity_times_unit_price():
    """정상 값이면 매출액(revenue)은 수량 × 단가로 계산된다."""
    record = make(quantity=3, unit_price=1_200_000.0)  # 3 × 1,200,000 = 3,600,000
    assert record.revenue == 3_600_000.0               # 계산 결과가 기대값과 같은가


def test_quantity_must_be_positive():
    """수량이 0 이하이면 도메인 오류(InvalidSalesRecordError)가 발생한다."""
    # pytest.raises(X): with 블록 안에서 X 예외가 나면 통과, 안 나면 실패.
    with pytest.raises(InvalidSalesRecordError):
        make(quantity=0)   # 수량 0 → 생성 단계에서 예외가 나야 정상


def test_unit_price_must_be_positive():
    """단가가 0 이하이면 도메인 오류가 발생한다."""
    with pytest.raises(InvalidSalesRecordError):
        make(unit_price=-100.0)   # 음수 단가 → 예외


def test_product_must_not_be_empty():
    """상품명이 비어 있으면(공백만 있어도) 도메인 오류가 발생한다."""
    with pytest.raises(InvalidSalesRecordError):
        make(product="   ")   # 공백뿐인 상품명도 '비어 있음'으로 취급 → 예외


def test_record_is_immutable():
    """레코드는 불변(frozen)이라 생성 후 필드를 바꿀 수 없다."""
    record = make()
    # frozen=True인 dataclass의 필드에 값을 대입하면 예외가 난다.
    with pytest.raises(Exception):
        record.quantity = 99  # type: ignore[misc]  # (타입 검사기 경고를 의도적으로 무시)


def test_records_with_same_values_are_equal():
    """같은 값으로 만든 두 레코드는 동등(==)하다.

    @dataclass가 __eq__를 자동 생성하므로, 모든 필드 값이 같으면 두 객체는 같다.
    별도 구현 없이 통과할 가능성이 크다(= 이미 보장된 동작을 확인하는 테스트).
    """
    assert make() == make()