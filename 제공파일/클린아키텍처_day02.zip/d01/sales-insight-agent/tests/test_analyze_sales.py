from datetime import date

from sales_agent.domain.models import SalesRecord, AnalysisResult
from sales_agent.usecases.analyze_sales import AnalyzeSalesUseCase


class FakeSalesRepository:
    """SalesRepository 포트를 만족하는 테스트용 가짜 리포지토리.

    파일을 읽지 않고 미리 준비한 레코드를 그대로 돌려준다.
    덕분에 'CSV 적재'와 무관하게 '분석 계산'만 격리해서 검증할 수 있다.
    """

    def __init__(self, records):
        self._records = records   # 테스트가 정한 입력 레코드를 보관

    def load(self):
        return self._records      # 포트 약속(load)을 그대로 흉내


def sample_records():
    """검증에 쓸 '고정 입력'. 기대 결과를 손으로 암산할 수 있게 숫자를 단순화했다."""
    return [
        # SalesRecord(날짜, 상품, 지역, 수량, 단가)  → 주석은 그 행의 매출액
        SalesRecord(date(2024, 1, 5), "노트북", "서울", 5, 1_000_000),  # 5 × 1,000,000 = 5,000,000
        SalesRecord(date(2024, 1, 6), "마우스", "부산", 10, 20_000),    # 10 × 20,000   =   200,000
        SalesRecord(date(2024, 2, 11), "노트북", "서울", 2, 1_000_000), # 2 × 1,000,000 = 2,000,000
    ]


def make_result():
    """가짜 리포지토리를 끼운 유스케이스를 실행해 분석 결과를 돌려주는 헬퍼."""
    repo = FakeSalesRepository(sample_records())   # 입력 고정
    return AnalyzeSalesUseCase(repo).execute()     # 포트로 주입 → 실행


def test_total_revenue():
    """총매출은 모든 레코드 매출액의 합이다."""
    # 5,000,000 + 200,000 + 2,000,000 = 7,200,000
    assert make_result().total_revenue == 7_200_000


def test_total_quantity():
    """총수량은 모든 레코드 수량의 합이다."""
    # 5 + 10 + 2 = 17
    assert make_result().total_quantity == 17


def test_period_range():
    """기간은 가장 이른 날짜부터 가장 늦은 날짜까지다."""
    result = make_result()
    assert result.period_start == date(2024, 1, 5)   # 최소 날짜
    assert result.period_end == date(2024, 2, 11)    # 최대 날짜


def test_by_product_aggregation():
    """상품별 매출이 합산된다(같은 '노트북' 두 건이 하나로 합쳐진다)."""
    by_product = make_result().by_product
    assert by_product["노트북"] == 7_000_000   # 5,000,000 + 2,000,000
    assert by_product["마우스"] == 200_000


def test_by_region_aggregation():
    """지역별 매출이 합산된다."""
    by_region = make_result().by_region
    assert by_region["서울"] == 7_000_000   # 노트북 두 건 모두 서울
    assert by_region["부산"] == 200_000


def test_by_month_aggregation():
    """월(YYYY-MM)별 매출이 합산된다."""
    by_month = make_result().by_month
    assert by_month["2024-01"] == 5_200_000   # 1월: 5,000,000 + 200,000
    assert by_month["2024-02"] == 2_000_000   # 2월: 2,000,000


def test_top_products_is_sorted():
    """상위 상품은 매출 내림차순으로 정렬된다(가장 큰 것이 맨 앞)."""
    top = make_result().top_products
    assert top[0] == ("노트북", 7_000_000)   # 1위는 노트북


def test_empty_records_raises():
    """레코드가 하나도 없으면 분석할 대상이 없으므로 오류를 던진다."""
    import pytest
    with pytest.raises(ValueError):
        # 빈 목록을 가진 가짜를 주입 → execute()에서 ValueError가 나야 정상
        AnalyzeSalesUseCase(FakeSalesRepository([])).execute()


def test_average_order_value():
    """평균 객단가는 총매출 / 총수량이다."""
    result = make_result()
    assert result.average_order_value == 7_200_000 / 17


def test_average_order_value_zero_quantity():
    """총수량이 0이면 평균 객단가는 0을 반환한다(0으로 나누는 대신)."""
    empty = AnalysisResult(
        total_revenue=0.0,
        total_quantity=0,
        period_start=date(2024, 1, 1),
        period_end=date(2024, 1, 1),
    )
    assert empty.average_order_value == 0.0