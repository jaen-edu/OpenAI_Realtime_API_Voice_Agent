from pathlib import Path  # 경로를 객체로 다루는 표준 모듈(문자열 결합보다 안전)

import pytest


@pytest.fixture  # 이 함수를 'pytest 픽스처(준비물 제공자)'로 등록한다
def csv_file(tmp_path: Path):
    """주어진 내용으로 임시 CSV 파일을 만들어 그 '경로'를 돌려주는 팩토리.

    tmp_path: pytest가 테스트마다 자동으로 만들어 주는 '전용 임시 폴더' 픽스처.
              테스트가 끝나면 자동 삭제되므로 실제 프로젝트를 더럽히지 않는다.

    반환값이 '경로'가 아니라 '경로를 만들어 주는 함수(_make)'인 점에 주목.
    덕분에 각 테스트가 원하는 CSV 내용을 그때그때 넣어 파일을 만들 수 있다.
    """

    def _make(content: str) -> Path:
        """content 문자열을 임시 CSV 파일로 쓰고 그 경로를 반환한다."""
        p = tmp_path / "sales.csv"                 # 임시 폴더 안의 파일 경로(/ 연산자로 결합)
        p.write_text(content, encoding="utf-8")    # 한글이 깨지지 않도록 UTF-8로 기록
        return p

    return _make   # 함수 자체를 반환 → 테스트에서 csv_file("...")처럼 호출