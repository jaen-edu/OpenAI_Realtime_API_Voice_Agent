from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime  # 문자열 → 날짜 변환(strptime)에 사용

import pandas as pd  # 어댑터(3계층)이므로 외부 라이브러리 사용 OK

from sales_agent.domain.errors import InvalidSalesRecordError
from sales_agent.domain.models import SalesRecord

# CSV에 반드시 있어야 하는 컬럼 목록. 하나라도 없으면 '파일 구조 오류'로 본다.
REQUIRED_COLUMNS = ["date", "product", "region", "quantity", "unit_price"]


@dataclass(frozen=True)
class SkippedRow:
    """적재에서 제외된 행 1건의 정보(행 번호 + 사유)를 담는 불변 객체."""

    line: int     # 사용자가 보는 실제 CSV 행 번호(1부터, 헤더 포함)
    reason: str   # 제외된 이유(예: "quantity must be > 0, got 0")


class CsvSalesRepository:
    """CSV 파일에서 매출 레코드를 적재하는 어댑터.

    usecases.ports.SalesRepository 프로토콜(load 메서드)을 구현한다.
    '더러운 CSV'를 받아 '깨끗한 도메인 객체 목록'으로 통역하는 것이 책임이다.
    """

    def __init__(self, path: str) -> None:
        """path: 읽어들일 CSV 파일 경로."""
        self._path = path
        # 적재 중 제외된 행들을 모아 둘 목록. 호출자(화면 등)가 사유를 보여 줄 수 있다.
        self.skipped: list[SkippedRow] = []

    def load(self) -> list[SalesRecord]:
        """CSV를 읽어 유효한 SalesRecord 목록을 반환한다.

        - 한 행만 잘못된 경우 → self.skipped에 사유를 기록하고 그 행만 건너뛴다.
        - 필수 컬럼이 통째로 없는 경우 → ValueError로 전체를 중단한다.
        """
        # dtype=str: 모든 값을 일단 문자열로 읽는다(숫자 자동 변환으로 인한 오작동 방지).
        # fillna(""): 빈 칸(NaN)을 빈 문자열로 바꿔 이후 .strip() 등에서 오류가 안 나게.
        df = pd.read_csv(self._path, dtype=str).fillna("")

        # 필수 컬럼 중 실제 파일에 없는 것들을 모은다.
        missing = [c for c in REQUIRED_COLUMNS if c not in df.columns]
        if missing:  # 하나라도 없으면 파일 구조 자체가 잘못된 것 → 중단
            raise ValueError(f"필수 컬럼 누락: {missing}")

        self.skipped = []                      # 매 호출마다 제외 목록 초기화
        records: list[SalesRecord] = []
        for i, row in df.iterrows():           # i: 0기반 행 인덱스, row: 한 행(Series)
            try:
                records.append(self._to_record(row))  # 변환 성공 → 목록에 추가
            except (InvalidSalesRecordError, ValueError) as e:
                # 변환/검증 실패 → 그 행만 건너뛰고 사유를 기록한다.
                # 실제 행 번호 = 0기반 인덱스(i) + 헤더 1줄 + 1 = i + 2
                self.skipped.append(SkippedRow(line=int(i) + 2, reason=str(e)))
        return records

    @staticmethod
    def _to_record(row: pd.Series) -> SalesRecord:
        """한 행(문자열들)을 적절한 타입으로 변환해 SalesRecord로 만든다.

        여기서 SalesRecord를 생성하는 순간, 도메인의 __post_init__ 검증이 자동 실행된다.
        즉 수량/단가/상품명 규칙 위반은 이 한 줄에서 예외로 걸러진다(검증 중복 없음).
        """
        return SalesRecord(
            # "2024-01-05" 형식 문자열을 date 객체로 변환. 형식이 다르면 여기서 예외.
            date=datetime.strptime(row["date"].strip(), "%Y-%m-%d").date(),
            product=row["product"].strip(),       # 앞뒤 공백 제거
            region=row["region"].strip(),
            quantity=int(row["quantity"]),        # 문자열 → 정수(실패 시 예외)
            unit_price=float(row["unit_price"]),  # 문자열 → 실수(실패 시 예외)
        )