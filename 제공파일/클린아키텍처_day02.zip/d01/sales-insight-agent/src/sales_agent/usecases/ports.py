from __future__ import annotations

# Protocol: '이런 메서드를 가진 것이면 무엇이든 이 타입으로 인정'하는 구조적 타이핑 도구.
# 어댑터가 이 클래스를 명시적으로 상속하지 않아도, 같은 모양의 메서드만 있으면 만족한다.
from typing import Protocol

from sales_agent.domain.models import AnalysisResult, SalesRecord


class SalesRepository(Protocol):
    """매출 레코드를 '어딘가에서' 적재한다는 약속(포트).

    '어딘가'가 CSV인지 DB인지 API인지는 이 약속이 신경 쓰지 않는다.
    실제 구현(예: CsvSalesRepository)은 바깥의 어댑터 계층이 담당한다.
    """

    # `...`(Ellipsis)는 '본문 없음'을 뜻한다. 약속(시그니처)만 정의하고 구현은 비운다.
    def load(self) -> list[SalesRecord]:
        """매출 레코드 목록을 반환한다."""
        ...


class ChartRenderer(Protocol):
    """분석 결과로 차트 이미지를 만든다는 약속(포트)."""

    def render(self, result: AnalysisResult, out_dir: str) -> list[str]:
        """분석 결과를 out_dir에 차트로 그리고, 생성된 이미지 경로 목록을 반환한다."""
        ...


class InsightGateway(Protocol):
    """분석 결과를 자연어 인사이트로 요약한다는 약속(포트, LLM 담당)."""

    def summarize(self, result: AnalysisResult) -> str:
        """분석 결과를 받아 한국어 요약 문장을 반환한다."""
        ...