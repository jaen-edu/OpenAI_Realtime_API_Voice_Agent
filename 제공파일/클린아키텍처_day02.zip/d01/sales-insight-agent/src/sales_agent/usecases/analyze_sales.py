from __future__ import annotations

# defaultdict(float): 처음 보는 키를 자동으로 0.0으로 초기화해 주는 사전.
# 덕분에 "키가 있으면 더하고, 없으면 0부터" 같은 조건문 없이 += 만으로 누적할 수 있다.
from collections import defaultdict

from sales_agent.domain.models import AnalysisResult
from sales_agent.usecases.ports import SalesRepository  # 추상(포트)만 import


class AnalyzeSalesUseCase:
    """매출 레코드를 분석해 AnalysisResult(지표 묶음)를 만드는 유스케이스.

    데이터 출처(CSV/DB/API)도, pandas도, 화면도 모른다. 오직 포트와 도메인만 안다.
    """

    def __init__(self, repository: SalesRepository) -> None:
        # 추상(포트)에만 의존한다 → CsvSalesRepository, FakeSalesRepository 등
        # load()를 가진 무엇이든 주입할 수 있다(의존성 역전).
        self._repository = repository

    def execute(self) -> AnalysisResult:
        """레코드를 적재한 뒤 각종 지표를 집계해 AnalysisResult로 반환한다."""
        records = self._repository.load()   # 포트를 통해 레코드 확보(출처는 모른 채)
        if not records:                     # 빈 목록이면 분석할 대상이 없음
            raise ValueError("분석할 매출 레코드가 없습니다.")

        # 기준별 매출 누적용 사전 3개(상품/지역/월). 모두 0.0에서 시작.
        by_product: dict[str, float] = defaultdict(float)
        by_region: dict[str, float] = defaultdict(float)
        by_month: dict[str, float] = defaultdict(float)

        total_revenue = 0.0
        total_quantity = 0
        for r in records:                              # 레코드를 한 번 순회하며 동시에 집계
            total_revenue += r.revenue                 # 전체 매출 누적(도메인의 계산값 사용)
            total_quantity += r.quantity               # 전체 수량 누적
            by_product[r.product] += r.revenue         # 상품별 매출 누적
            by_region[r.region] += r.revenue           # 지역별 매출 누적
            by_month[r.date.strftime("%Y-%m")] += r.revenue  # "2024-01" 형태 월 키로 누적

        dates = [r.date for r in records]              # 기간 계산용 날짜 모음
        return AnalysisResult(
            total_revenue=total_revenue,
            total_quantity=total_quantity,
            period_start=min(dates),                   # 가장 이른 날짜
            period_end=max(dates),                     # 가장 늦은 날짜
            # defaultdict를 일반 dict로 변환해 반환(불필요한 자동 생성 동작 차단).
            by_product=dict(by_product),
            by_region=dict(by_region),
            by_month=dict(by_month),
        )