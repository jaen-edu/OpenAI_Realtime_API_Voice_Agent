class DomainError(Exception):
    """도메인 규칙 위반의 최상위(부모) 예외.

    바깥 계층에서 `except DomainError:` 한 줄로 도메인이 의도적으로 던진
    모든 규칙 위반을 한꺼번에 잡을 수 있게 해 주는 공통 조상이다.
    """


class InvalidSalesRecordError(DomainError):
    """매출 레코드가 도메인 규칙(양수 수량/단가, 비어 있지 않은 상품명)을 어겼을 때 발생."""