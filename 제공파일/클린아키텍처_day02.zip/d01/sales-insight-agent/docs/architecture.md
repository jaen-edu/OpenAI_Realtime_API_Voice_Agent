# 계층 배치 결정

| 기능 | 계층 | 파일(예정) |
|---|---|---|
| F1 SalesRecord        | domain(엔티티)   | domain/models.py |
| F3 분석 결과 구조      | domain(엔티티)   | domain/models.py (AnalysisResult) |
| F3 분석 로직          | usecase          | usecases/analyze_sales.py |
| 데이터 적재 약속(포트) | usecase          | usecases/ports.py (SalesRepository) |
| F2 CSV 적재 구현       | adapter          | adapters/csv_repository.py |
| F4 차트 생성           | adapter          | adapters/chart_renderer.py |
| F5 LLM 요약            | adapter          | adapters/llm_gateway.py |
| F6 리포트 조립         | usecase          | usecases/generate_report.py |
| F7 웹 UI              | infra/UI         | app.py |
| OpenAI 클라이언트      | infra            | infra/openai_client.py |

## 의존성 규칙 자가 점검
- [ ] domain은 다른 어떤 계층도, 외부 라이브러리도 import 하지 않는다.
- [ ] usecase는 domain과 ports(추상)에만 의존한다(구체 어댑터 import 금지).
- [ ] adapter는 외부 라이브러리(pandas/matplotlib/openai)를 사용해도 된다.
- [ ] infra/UI(app.py)가 구체 어댑터를 생성해 유스케이스에 끼워 넣는다(조립).