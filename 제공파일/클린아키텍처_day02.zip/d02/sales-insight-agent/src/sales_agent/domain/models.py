from __future__ import annotations

from dataclasses import dataclass, field
from datetime import date

from sales_agent.domain.errors import InvalidSalesRecordError


@dataclass(frozen=True)  # 자동 생성자/비교 + 불변(생성 후 수정 불가)
class SalesRecord:
    """매출 한 건을 표현하는 불변 값 객체.

    생성 시점에 검증을 통과하므로, 'SalesRecord 객체가 존재한다'는 곧
    '유효한 매출 한 건이다'를 보장한다.
    """

    date: date          # 거래 일자
    product: str        # 상품명
    region: str         # 지역명
    quantity: int       # 수량 (> 0)
    unit_price: float   # 단가 (> 0)

    def __post_init__(self) -> None:
        """모든 필드가 채워진 직후 호출되어 도메인 규칙을 검증한다.

        오류 메시지에 실제 값(got ...)을 함께 넣어, 어떤 값 때문에 실패했는지
        디버깅·로그에서 바로 알 수 있게 한다.
        """
        
        self._require_positive("quantity", self.quantity)     # 수량 검증 위임
        self._require_positive("unit_price", self.unit_price)  # 단가 검증 위임
        if not self.product.strip():
            raise InvalidSalesRecordError("product must not be empty")

    @property
    def revenue(self) -> float:
        """매출액 = 수량 × 단가 (저장하지 않고 매번 계산)."""
        return self.quantity * self.unit_price
    

    @staticmethod  # self를 쓰지 않는 순수 보조 함수라 정적 메서드로 둔다
    def _require_positive(field_name: str, value: float) -> None:
        """값이 0 이하이면 도메인 오류를 던지는 공통 검증.

        field_name: 오류 메시지에 표시할 필드 이름(예: "quantity")
        value: 검사할 실제 값
        """
        if value <= 0:
            raise InvalidSalesRecordError(f"{field_name} must be > 0, got {value}")
        

# SalesRecord 정의 아래에 AnalysisResult 를 추가한다.
@dataclass(frozen=True)
class AnalysisResult:
    """분석 산출물을 담는 불변 객체. 이 교시의 유스케이스가 값을 채운다.

    필드:
        total_revenue: 전체 매출 합계
        total_quantity: 전체 판매 수량 합계
        period_start / period_end: 데이터의 가장 이른/늦은 날짜
        by_product / by_region / by_month: 각 기준별 매출 합계 사전(dict)
    """

    total_revenue: float
    total_quantity: int
    period_start: date
    period_end: date
    # field(default_factory=dict): 인스턴스마다 '새로운 빈 dict'를 기본값으로 준다.
    # (= {} 로 쓰면 모든 인스턴스가 같은 dict를 공유하는 고전적 버그가 생긴다.)
    by_product: dict[str, float] = field(default_factory=dict)  # 상품명 → 매출 합계
    by_region: dict[str, float] = field(default_factory=dict)   # 지역명 → 매출 합계
    by_month: dict[str, float] = field(default_factory=dict)    # "YYYY-MM" → 매출 합계

    @property
    def top_products(self) -> list[tuple[str, float]]:
        """상품별 매출을 '매출 내림차순'으로 정렬한 (상품명, 매출) 목록을 돌려준다."""
        return sorted(self.by_product.items(), key=lambda kv: kv[1], reverse=True)
    

    @property
    def average_order_value(self) -> float:
        """평균 객단가 = 총매출 / 총수량. 수량이 0이면 0을 반환한다."""
        if self.total_quantity == 0:
            return 0.0
        return self.total_revenue / self.total_quantity
    

@dataclass(frozen=True)
class Report:
    """사용자에게 최종 제공되는 리포트. 9교시의 리포트 유스케이스가 조립한다.

    필드:
        title: 리포트 제목
        summary: LLM이 생성한 자연어 인사이트
        result: 위 분석 결과(숫자) 묶음
        chart_paths: 생성된 차트 이미지 파일 경로 목록
    """

    title: str
    summary: str                     # LLM이 생성한 인사이트(자연어 문장)
    result: AnalysisResult           # 숫자 분석 결과(차트·표시에 재사용)
    chart_paths: list[str] = field(default_factory=list)  # 차트 png 경로들