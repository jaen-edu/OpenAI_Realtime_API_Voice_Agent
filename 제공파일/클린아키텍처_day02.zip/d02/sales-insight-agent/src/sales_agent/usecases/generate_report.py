from __future__ import annotations

from pathlib import Path

from sales_agent.domain.models import AnalysisResult, Report
from sales_agent.usecases.ports import ChartRenderer, InsightGateway  # 추상(포트)만 import


class GenerateReportUseCase:
    """분석 결과를 차트·AI 요약과 함께 하나의 리포트로 조립하는 유스케이스.

    스스로 차트를 그리거나 LLM을 부르지 않는다. 두 포트에게 '시키고' 결과만 조립한다.
    """

    def __init__(self, chart_renderer: ChartRenderer, insight_gateway: InsightGateway) -> None:
        # 두 포트(추상)에만 의존 → 진짜 어댑터든 Fake든 주입 가능.
        self._charts = chart_renderer
        self._insight = insight_gateway

    def execute(self, result: AnalysisResult, out_dir: str) -> tuple[Report, str]:
        """차트 생성 → 요약 생성 → 리포트 객체 조립 → 마크다운 저장 순으로 진행한다.

        반환: (조립된 Report 객체, 저장된 마크다운 파일 경로) 튜플.
        """
        chart_paths = self._charts.render(result, out_dir)  # 포트①: 차트 그리기 위임
        summary = self._insight.summarize(result)           # 포트②: AI 요약 위임

        report = Report(                                    # 결과들을 도메인 객체로 조립
            title="매출 인사이트 리포트",
            summary=summary,
            result=result,
            chart_paths=chart_paths,
        )
        md_path = self._write_markdown(report, out_dir)     # 사람이 읽을 .md로 저장
        return report, md_path

    @staticmethod
    def _write_markdown(report: Report, out_dir: str) -> str:
        """Report 객체를 마크다운 텍스트로 직렬화해 report.md로 저장한다."""
        r = report.result
        # 리포트 본문을 줄 단위 리스트로 구성한 뒤 마지막에 합친다(읽기 쉬움).
        lines = [
            f"# {report.title}",
            "",
            f"- 기간: {r.period_start} ~ {r.period_end}",
            f"- 총매출: {r.total_revenue:,.0f}원",
            f"- 총수량: {r.total_quantity}개",
            "",
            "## AI 인사이트",
            report.summary,
            "",
            "## 차트",
            # 차트 경로마다 마크다운 이미지 문법 ![](경로)을 한 줄씩 생성(*: 리스트 펼치기)
            *[f"![chart]({p})" for p in report.chart_paths],
        ]
        path = Path(out_dir) / "report.md"
        path.parent.mkdir(parents=True, exist_ok=True)        # 출력 폴더 보장
        path.write_text("\n".join(lines), encoding="utf-8")   # 줄들을 개행으로 이어 UTF-8 저장
        return str(path)