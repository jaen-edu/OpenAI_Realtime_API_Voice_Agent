from __future__ import annotations

from sales_agent.domain.models import AnalysisResult


class OpenAiInsightGateway:
    """분석 결과를 LLM으로 요약하는 어댑터.

    usecases.ports.InsightGateway 프로토콜(summarize 메서드)을 구현한다.
    OpenAI 클라이언트를 '주입'받으므로, 테스트에서는 Fake 클라이언트로 갈아 끼워
    네트워크·과금 없이 검증할 수 있다.
    """

    def __init__(self, client, model: str = "gpt-4.1-mini") -> None:
        """client: chat.completions.create(...)를 가진 OpenAI 클라이언트(또는 Fake).
        model: 사용할 모델 이름. 기본값을 '이 한 곳'에만 두어 교체 지점을 단일화한다.
        """
        self._client = client
        self._model = model

    def summarize(self, result: AnalysisResult) -> str:
        """분석 결과(숫자)를 받아 LLM이 만든 한국어 요약 문장을 반환한다."""
        prompt = self._build_prompt(result)   # 계산된 숫자로 프롬프트 구성
        response = self._client.chat.completions.create(
            model=self._model,
            messages=[
                # system: LLM의 역할·제약을 규정. "주어진 숫자만 근거로" → 환각 억제.
                {"role": "system", "content": "너는 매출 데이터를 해석하는 분석가다. "
                                              "주어진 숫자만 근거로, 한국어로 3~4문장 요약하라."},
                # user: 실제 분석 숫자가 담긴 프롬프트.
                {"role": "user", "content": prompt},
            ],
        )
        # 응답 구조: response.choices[0].message.content. 앞뒤 공백은 제거한다.
        return response.choices[0].message.content.strip()

    @staticmethod
    def _build_prompt(result: AnalysisResult) -> str:
        """'코드가 계산한 숫자'만으로 프롬프트를 만든다(원본 CSV는 절대 보내지 않는다).

        f"{값:,.0f}" 포맷: 천 단위 콤마(,) + 소수점 0자리 정수 표기.
        예) 7200000 → "7,200,000"
        """
        # 상위 3개 상품을 "상품 금액원, ..." 형태 문자열로 연결.
        top = ", ".join(f"{name} {value:,.0f}원" for name, value in result.top_products[:3])
        # 월별 매출을 시간순으로 정렬해 "2024-01 금액원, ..." 형태로 연결.
        months = ", ".join(f"{m} {v:,.0f}원" for m, v in sorted(result.by_month.items()))
        return (
            f"분석 기간: {result.period_start} ~ {result.period_end}\n"
            f"총매출: {result.total_revenue:,.0f}원\n"
            f"총수량: {result.total_quantity}개\n"
            f"상위 상품: {top}\n"
            f"월별 매출: {months}\n\n"
            f"위 숫자를 근거로 핵심 인사이트를 요약해 줘."
        )