from __future__ import annotations

from pathlib import Path

import matplotlib

# ⚠️ 반드시 pyplot을 import 하기 '전에' 백엔드를 지정해야 효과가 있다.
# "Agg"는 화면 창 없이 파일로만 그리는 모드 → 디스플레이 없는 서버/CI/교육장에서도 동작.
matplotlib.use("Agg")

import matplotlib.pyplot as plt  # noqa: E402  (백엔드 설정 뒤 import 하려는 의도적 순서)

from sales_agent.domain.models import AnalysisResult


class MatplotlibChartRenderer:
    """분석 결과를 차트 이미지(png)로 렌더링하는 어댑터.

    usecases.ports.ChartRenderer 프로토콜(render 메서드)을 구현한다.
    값을 반환할 뿐 아니라 '파일을 생성'하는 부수효과를 가진 점이 유스케이스와 다르다.
    """

    def __init__(self) -> None:
        # rcParams: matplotlib 전역 설정. 한글 라벨이 깨지지 않도록 폰트 후보를 지정한다.
        # 앞에서부터 설치된 폰트를 사용(Windows=Malgun Gothic, mac=AppleGothic, 그 외=DejaVu).
        plt.rcParams["font.family"] = ["Malgun Gothic", "DejaVu Sans"]
        plt.rcParams["axes.unicode_minus"] = False  # 마이너스 기호(−)가 깨지는 현상 방지

    def render(self, result: AnalysisResult, out_dir: str) -> list[str]:
        """상위 상품 차트와 월별 추이 차트를 그려 생성된 파일 경로 목록을 반환한다."""
        out = Path(out_dir)
        out.mkdir(parents=True, exist_ok=True)  # 폴더가 없으면 만든다(parents: 중간 폴더까지)

        # 두 차트를 각각 그리고 경로를 모아 반환. 차트를 늘리려면 여기 항목만 추가하면 된다.
        return [
            self._bar_top_products(result, out),
            self._line_monthly(result, out),
            self._bar_by_region(result, out)
        ]

    def _bar_top_products(self, result: AnalysisResult, out: Path) -> str:
        """상위 5개 상품의 매출을 막대 차트로 그려 파일 경로를 반환한다."""
        top = result.top_products[:5]                 # 매출 상위 5개 (상품명, 매출) 쌍
        names = [name for name, _ in top]             # x축 라벨: 상품명들
        values = [value for _, value in top]          # y축 값: 매출들

        fig, ax = plt.subplots()                      # 새 도화지(fig)와 좌표축(ax) 생성
        ax.bar(names, values)                         # 막대 그래프
        ax.set_title("상위 상품별 매출")
        ax.set_ylabel("매출(원)")
        path = out / "top_products.png"
        fig.savefig(path, bbox_inches="tight")        # 파일로 저장(여백 자동 정리)
        plt.close(fig)                                # ⚠️ 메모리 누수 방지: 그린 figure는 닫는다
        return str(path)

    def _line_monthly(self, result: AnalysisResult, out: Path) -> str:
        """월별 매출 추이를 선 차트로 그려 파일 경로를 반환한다."""
        months = sorted(result.by_month.keys())       # 월 키를 시간순으로 정렬("2024-01"…)
        values = [result.by_month[m] for m in months] # 각 월의 매출

        fig, ax = plt.subplots()
        ax.plot(months, values, marker="o")           # 선 그래프(각 점에 동그라미 표시)
        ax.set_title("월별 매출 추이")
        ax.set_ylabel("매출(원)")
        path = out / "monthly_trend.png"
        fig.savefig(path, bbox_inches="tight")
        plt.close(fig)                                # 여기서도 반드시 닫는다
        return str(path)
    

    def _bar_by_region(self, result: AnalysisResult, out: Path) -> str:
        """지역별 매출을 막대 차트로 그려 파일 경로를 반환한다."""
        names = list(result.by_region.keys())       # 지역 키
        values = list(result.by_region.values())     # 각 지역의 매출
        
        fig, ax = plt.subplots()                      # 새 도화지(fig)와 좌표축(ax) 생성
        ax.bar(names, values)                         # 막대 그래프
        ax.set_title("지역별 매출")
        ax.set_ylabel("매출(원)")
        path = out / "by_region.png"
        fig.savefig(path, bbox_inches="tight")        # 파일로 저장(여백 자동 정리)
        plt.close(fig)                                # ⚠️ 메모리 누수 방지: 그린 figure는 닫는다
        return str(path)