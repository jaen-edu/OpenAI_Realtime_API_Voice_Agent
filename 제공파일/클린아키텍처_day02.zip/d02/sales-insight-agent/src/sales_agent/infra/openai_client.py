from __future__ import annotations

import os  # 환경 변수 접근

from dotenv import load_dotenv  # .env 파일을 읽어 환경 변수로 올려 주는 라이브러리
from openai import OpenAI       # 공식 OpenAI 클라이언트


def make_openai_client() -> OpenAI:
    """.env에서 API 키를 읽어 OpenAI 클라이언트를 생성하는 '팩토리' 함수.

    비밀값(API 키)을 다루는 코드는 가장 바깥(인프라 계층) 이 한 곳에만 둔다.
    도메인·유스케이스·어댑터 어디에도 키가 등장하지 않아 유출 위험이 최소화된다.
    """
    load_dotenv()                                # 프로젝트의 .env를 찾아 환경 변수로 로드
    api_key = os.environ.get("OPENAI_API_KEY")   # 환경 변수에서 키를 읽음(없으면 None)
    if not api_key:                              # 키가 비어 있으면 명확한 안내와 함께 중단
        raise RuntimeError("OPENAI_API_KEY가 설정되지 않았습니다. .env를 확인하세요.")
    return OpenAI(api_key=api_key)               # 키를 넣어 실제 클라이언트 생성·반환