from datetime import date

from sales_agent.domain.models import AnalysisResult
from sales_agent.adapters.llm_gateway import OpenAiInsightGateway


class FakeChatCompletions:
    """OpenAI 클라이언트의 chat.completions.create(...)를 흉내 내는 가짜.

    실제 네트워크 호출 대신, 들어온 프롬프트를 기록하고 고정된 응답을 돌려준다.
    덕분에 테스트가 빠르고, 과금되지 않으며, 인터넷 없이도 동작한다.
    """

    def __init__(self):
        self.last_prompt = None      # 마지막으로 전달된 사용자 프롬프트를 보관(검사용)

    def create(self, model, messages, **kwargs):
        # messages[-1]은 마지막 메시지(=user 프롬프트). 그 content를 저장해 둔다.
        self.last_prompt = messages[-1]["content"]

        # 아래 중첩 클래스들은 실제 OpenAI 응답 구조(resp.choices[0].message.content)를
        # 똑같이 흉내 내기 위한 최소 껍데기다.
        class _Msg:
            content = "노트북이 전체 매출을 견인했습니다. 1월 매출이 가장 높았습니다."

        class _Choice:
            message = _Msg()

        class _Resp:
            choices = [_Choice()]

        return _Resp()


class FakeClient:
    """OpenAI 클라이언트 모양(client.chat.completions.create)을 갖춘 가짜."""

    def __init__(self):
        # type("chat", (), {...})(): 'completions' 속성을 가진 익명 객체를 즉석 생성.
        # 결과적으로 client.chat.completions.create(...) 경로를 그대로 흉내 낸다.
        self.chat = type("chat", (), {"completions": FakeChatCompletions()})()


def make_result() -> AnalysisResult:
    """LLM 요약 입력으로 쓸 고정 분석 결과."""
    return AnalysisResult(
        total_revenue=7_200_000,
        total_quantity=17,
        period_start=date(2024, 1, 5),
        period_end=date(2024, 2, 11),
        by_product={"노트북": 7_000_000, "마우스": 200_000},
        by_region={"서울": 7_000_000, "부산": 200_000},
        by_month={"2024-01": 5_200_000, "2024-02": 2_000_000},
    )


def test_summarize_returns_text():
    """요약은 비어 있지 않은 문자열을 반환한다."""
    client = FakeClient()                                            # 가짜 클라이언트 주입
    gateway = OpenAiInsightGateway(client=client, model="gpt-4.1-mini")

    summary = gateway.summarize(make_result())

    assert isinstance(summary, str)   # 반환 타입이 문자열인가
    assert len(summary) > 0           # 빈 문자열이 아닌가


def test_prompt_contains_computed_numbers():
    """프롬프트에는 '코드가 계산한 숫자'가 담긴다(원본 CSV가 아니라)."""
    client = FakeClient()
    gateway = OpenAiInsightGateway(client=client, model="gpt-4.1-mini")

    gateway.summarize(make_result())

    # 가짜 클라이언트가 기록해 둔 '실제로 보낸 프롬프트'를 꺼내 검사한다.
    sent = client.chat.completions.last_prompt
    assert "7,200,000" in sent or "7200000" in sent   # 총매출(계산값)이 프롬프트에 포함됐는가
    assert "노트북" in sent                            # 상위 상품(계산값)이 포함됐는가