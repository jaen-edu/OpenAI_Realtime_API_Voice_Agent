from datetime import date
from pathlib import Path

from sales_agent.domain.models import AnalysisResult
from sales_agent.adapters.chart_renderer import MatplotlibChartRenderer


def make_result() -> AnalysisResult:
    """차트 입력으로 쓸 고정된 분석 결과를 만든다(테스트가 항상 같은 그림을 그리도록)."""
    return AnalysisResult(
        total_revenue=7_200_000,
        total_quantity=17,
        period_start=date(2024, 1, 5),
        period_end=date(2024, 2, 11),
        by_product={"노트북": 7_000_000, "마우스": 200_000},  # 막대 차트 입력
        by_region={"서울": 7_000_000, "부산": 200_000},
        by_month={"2024-01": 5_200_000, "2024-02": 2_000_000},  # 선 차트 입력
    )


def test_render_contains_top_products_and_monthly_png(tmp_path: Path):
    """렌더링 결과에 상위상품/월별추이 png가 포함되고 실제 파일도 생성되는지 검증한다."""
    renderer = MatplotlibChartRenderer()

    # tmp_path(임시 폴더)에 차트를 그리게 한다. 반환값은 생성된 파일 경로 목록.
    paths = renderer.render(make_result(), str(tmp_path))

    names = {Path(p).name for p in paths}
    expected = {"top_products.png", "monthly_trend.png"}
    assert expected.issubset(names)              # 필수 차트 파일명이 모두 포함됐는가

    for filename in expected:
        f = tmp_path / filename
        assert f.exists()                        # 부수효과 검증①: 파일이 실제로 존재
        assert f.suffix == ".png"                # 부수효과 검증②: 확장자가 png
        assert f.stat().st_size > 0              # 부수효과 검증③: 빈 파일이 아님(크기>0)

    for p in paths:
        f = Path(p)
        assert f.suffix == ".png"                # 렌더러가 반환한 경로는 모두 png여야 한다


def test_render_into_given_directory(tmp_path: Path):
    """차트는 '호출자가 지정한 폴더' 안에 생성된다(경로 규약 확인)."""
    renderer = MatplotlibChartRenderer()

    paths = renderer.render(make_result(), str(tmp_path))

    for p in paths:
        assert str(tmp_path) in p                # 반환 경로에 지정 폴더가 포함돼 있는가


def test_render_contains_region_sales_png(tmp_path: Path):
    """렌더링 결과에 지역별 매출 챠트 파일이 포함되고 실제 파일도 생성되는지 검증한다."""
    renderer = MatplotlibChartRenderer()

    # tmp_path(임시 폴더)에 차트를 그리게 한다. 반환값은 생성된 파일 경로 목록.
    paths = renderer.render(make_result(), str(tmp_path))

    names = {Path(p).name for p in paths}
    assert "by_region.png" in names              # 필수 차트 파일명이 모두 포함됐는가

    region_chart = tmp_path / "by_region.png"
    assert region_chart.exists()                 # 부수효과 검증①: 파일이 실제로 존재
    assert region_chart.suffix == ".png"         # 부수효과 검증②: 확장자가 png
    assert region_chart.stat().st_size > 0       # 부수효과 검증
    