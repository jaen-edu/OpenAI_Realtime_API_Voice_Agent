from datetime import date
from pathlib import Path

from sales_agent.domain.models import AnalysisResult, Report
from sales_agent.usecases.generate_report import GenerateReportUseCase


class FakeChart:
    """ChartRenderer 포트를 만족하는 가짜. matplotlib 없이 더미 파일만 만든다."""

    def render(self, result, out_dir):
        p = Path(out_dir) / "chart.png"
        p.parent.mkdir(parents=True, exist_ok=True)  # 폴더 보장
        p.write_bytes(b"img")                        # 내용이 아무거나 들어간 더미 png
        return [str(p)]                              # 경로 목록 반환(실제 어댑터와 같은 모양)


class FakeInsight:
    """InsightGateway 포트를 만족하는 가짜. LLM 없이 고정 문장을 돌려준다."""

    def summarize(self, result):
        return "테스트 요약 인사이트"


def make_result() -> AnalysisResult:
    """리포트 조립에 넣을 최소한의 분석 결과."""
    return AnalysisResult(
        total_revenue=7_200_000, total_quantity=17,
        period_start=date(2024, 1, 5), period_end=date(2024, 2, 11),
        by_product={"노트북": 7_000_000}, by_region={"서울": 7_000_000},
        by_month={"2024-01": 7_200_000},
    )


def test_generate_report_assembles_all_parts(tmp_path):
    """리포트는 요약·차트·지표를 모두 담아 조립되고, 마크다운 파일로 저장된다."""
    # 두 가짜 어댑터를 주입 → 네트워크·matplotlib 없이 '조립 로직'만 검증
    usecase = GenerateReportUseCase(FakeChart(), FakeInsight())

    report, md_path = usecase.execute(make_result(), str(tmp_path))

    assert isinstance(report, Report)                  # 결과가 Report 객체인가
    assert report.summary == "테스트 요약 인사이트"      # 요약이 들어갔는가
    assert len(report.chart_paths) == 1                # 차트 경로가 담겼는가
    assert Path(md_path).exists()                      # 마크다운 리포트 파일이 생성됐는가
    assert "총매출" in Path(md_path).read_text(encoding="utf-8")  # 내용에 지표가 들어갔는가